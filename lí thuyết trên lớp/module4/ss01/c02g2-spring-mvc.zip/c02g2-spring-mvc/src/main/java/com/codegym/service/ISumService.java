package com.codegym.service;

public interface ISumService {
    int sum(int a, int b);
}
